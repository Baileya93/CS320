import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactTest {

	@Test
	public void testContactIDLessThan10() {
		assertThrows(IllegalArgumentException.class, ()-> new Contact("123", "John", "Doe", "1234567890", "123 Main St."));
	}
	
	
	
	@Test
	public void testContactIDGreaterThan10() {
		assertThrows(IllegalArgumentException.class, ()-> new Contact("12345678901", "Jane", "Doe "
				+ "", "5555555555", "789 Oak St."));
	}
	
}
	
