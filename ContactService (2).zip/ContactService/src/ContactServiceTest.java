import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {

	@Test
	public void testAddContact() {
		ContactService contactService = new ContactService();
		Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St.");
		contactService.addContact(contact);
		assertNotNull(contactService.getContact("1234567890"));
	}
	
	@Test
	public void testDeleteContact() {
		ContactService contactService = new ContactService();
		Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St.");
		contactService.addContact(contact);
		contactService.deleteContact("1234567890");
		assertNull(contactService.getContact("1234567890"));
	}
	
	@Test
	public void testUpdateFirstName() {
		ContactService contactService = new ContactService();
		Contact contact = new Contact("1", "John", "Doe", "1234567890", "123 Main St.");
		contactService.addContact(contact);
		assertNotNull("Jane", contactService.getContact("1234567890").getFirstName());	
	}
	
	public void testUpdateLastName() { 
		ContactService contactService = new ContactService();
		Contact contact = new Contact("1", "John", "Doe", "1234567890", "123 Main St.");
		contactService.addContact(contact);
		assertNotNull("Doe", contactService.getContact("1234567890").getLastName());
	}

	public void testUpdateAddress() {
		ContactService contactService = new ContactService();
		Contact contact = new Contact("1", "John", "Doe", "1234567890", "123 Main St.");
		contactService.addContact(contact);
		assertNotNull("789 Oak St", contactService.getContact("1234567890").getAddress());
	}
	
	public void testUpdatePhoneNumber() {
		ContactService contactService = new ContactService();
		Contact contact = new Contact("1", "John", "Doe", "1234567890", "123 Main St.");
		contactService.addContact(contact);
		assertNotNull("0987654321", contactService.getContact("1234567890").getPhoneNumber());
	}
}	