import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import java.util.Date;


public class AppointmentServiceTest {
	private AppointmentService appointmentService;
	
	@Before
	public void setUp() {
		appointmentService = new AppointmentService();
	}

	@Test
	public void testAddAppointment() {
		Appointment appointment = new Appointment("1", new Date(), "Test Appointment");
		appointmentService.addAppointment(appointment);
	}
	
	@Test
	public void testDeleteAppointment() {
		Appointment appointment = new Appointment("A123456789", new Date(), "Test Appointment");
		appointmentService.addAppointment(appointment);
		assertTrue(appointmentService.deleteAppointment("A123456789"));
	}
	
	@Test
	public void testDeleteNonExistentAppointment() {
		assertFalse(appointmentService.deleteAppointment("B123456789"));
	}
	@Test(expected = IllegalArgumentException.class)
	public void testAddNullAppointment() {
		appointmentService.addAppointment(null);
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void testDeleteNullAppointment() {
		appointmentService.addAppointment(null);
	}	
	@Test
	public void testGetAppointment() {
		Appointment appointment = new Appointment("A123456789", new Date(), "Test Appointment");
		appointmentService.addAppointment(appointment);
		assertEquals(appointment, appointmentService.getAppointment("A123456789"));
	}
}

