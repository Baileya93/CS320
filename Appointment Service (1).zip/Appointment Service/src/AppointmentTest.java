import static org.junit.Assert.*;
import org.junit.Test;
import java.util.Date;

public class AppointmentTest {


	@Test
	public void testCreateAppointment() {
		Appointment appointment = new Appointment("A00001", new Date(), "Appointment Descritpion");
		assertNotNull(appointment);
	}
	
	@Test
	public void testAppointmentID() {
		Appointment appointment = new Appointment("A00001", new Date(), "Appointment Description");
		assertEquals ("A00001", appointment.getAppointmentId());
	}
	
	@Test
	public void testAppointmentDate() {
		Date appointmentDate = new Date();
		Appointment appointment = new Appointment("A00001", appointmentDate, "Appointment Description");
		assertEquals(appointmentDate, appointment.getAppointmentDate());
	}
	
	@Test(expected = IllegalArgumentException.class) 
	public void testApppointmentDateInThePast() {
		Date appointmentDate = new Date(System.currentTimeMillis() - 1000*60*60*24);
		Appointment appointment = new Appointment("A00001", appointmentDate, "Appointment Description");
	}
	
	@Test(expected = NullPointerException.class)
	public void testAppointmentIdNull() {
		 Appointment appointment = new Appointment(null, new Date(), "Appointment Description");
	}
	
	@Test(expected = NullPointerException.class)
	public void testAppointmentDateNull() {
		Appointment appointment = new Appointment("A00001", null, "Appointment Description");
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void testAppointmnetDescriptionNull() {
		Appointment appointment = new Appointment("A00001", new Date(), null);
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void testAppointmentDescriptionTooLong() {
		String description = "Appointment Descritpion that is too long and should throw an IllegalArguemtnException";
		 Appointment appointment = new Appointment("A00001", new Date(), description);
	}
}


