import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class TaskServiceTest {

	@Test
	public void testAddTask() {
		TaskService taskService = new TaskService();
		Task task = new Task("12345", "Task 1", "Task Description 1");
		taskService.addTask(task);
		
		taskService.addTask(task);
		
		assertEquals(task, taskService.getTask("1"));
	}
	
	@Test
	public void testDeleteTask() {
		TaskService taskService = new TaskService();
		Task task = new Task("12345", "Task 1", "Task Description 1");
		taskService.addTask(task);
		
		taskService.deleteTask("1");
		
		assertNull(taskService.getTask("1"));
		
		
	}

	@Test
	public void testUpdateTaskName() {
		TaskService taskService = new TaskService();
		Task task = new Task("12345", "Task 1", "Task Description 1");
		taskService.addTask(task);
		
		taskService.updateTaskName("1", "Updated Task");
		
		assertEquals ("Updated Task", taskService.getTask("1").getName());
		
	}
	
	@Test
	public void testUpdateDescription() {
		TaskService taskService = new TaskService();
		Task task = new Task("12345", "Task 1", "Testing Task 1");
		taskService.addTask(task);
		
		taskService.updateTaskDescription("12345", "Updated Description");
		
		assertEquals("Updated Description", taskService.getTask("1").getDescription());
		
		
		}
}
