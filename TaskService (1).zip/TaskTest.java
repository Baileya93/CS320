import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;



public class TaskTest {

	@Test
	public void testTaskIdLength() {
		Task task = new Task("1234567890", "Test Task", "This is a test.");
		assertEquals("1234567890", task.getTaskId());
	}
		


	public void testTaskIdTooLong() {
		new Task("12345678901", "Test task", "This is a test.");
	}
	
	public void testNullTaskId() {
		new Task(null, "Test Task", "Test Description.");
	}
	
	public void testNameLength() {
		Task task = new Task("1234567890", "Test Task", "This is a test task.");
		assertEquals("Test Task", task.getName());
	}
}	
	
	
